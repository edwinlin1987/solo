angular.module('side', [])


.controller('SideController', function ($scope) {

});